#pragma once

#include <algorithm>
#include <cstdint>
#include <mutex>

// The AFE task records both VAD edges even when the main event bit coalesces them.
class VadTurn {
public:
    static constexpr int64_t kSilenceUs = 1000000;
    static constexpr int64_t kNoInputUs = 3000000;

    void Start(bool enabled, bool include_current_speech = false, int64_t now_us = 0) {
        std::lock_guard<std::mutex> lock(mutex_);
        const bool pending_speech =
            enabled && submitted_ && speech_sequence_ != submitted_sequence_;
        ++generation_;
        open_ = true;
        recognized_ = false;
        active_ = enabled;
        require_vad_ = enabled;
        // State-change handling can run before an already queued VAD event.
        if (pending_speech) {
            accept_audio_after_us_ = resume_from_us_;
        } else {
            accept_audio_after_us_ = include_current_speech && speaking_ ? last_speech_us_ : now_us;
        }
        resume_from_us_ = 0;
        submitted_ = false;
        if (!include_current_speech && !pending_speech) {
            speaking_ = false;
        }
        heard_speech_ = enabled && (pending_speech || (include_current_speech && speaking_));
        deadline_us_ = pending_speech && !speaking_ ? last_silence_us_ + kSilenceUs : 0;
        no_input_deadline_us_ = now_us + kNoInputUs;
    }

    void ObserveVoice(bool speaking, int64_t now_us) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (speaking == speaking_) {
            return;
        }
        speaking_ = speaking;
        if (speaking) {
            ++speech_sequence_;
            last_speech_us_ = now_us;
            if (submitted_ && resume_from_us_ == 0) {
                resume_from_us_ = now_us;
            }
        } else {
            last_silence_us_ = now_us;
        }
        if (!active_ || submitted_) {
            return;
        }
        if (speaking) {
            heard_speech_ = true;
            deadline_us_ = 0;
        } else if (heard_speech_) {
            deadline_us_ = now_us + kSilenceUs;
        }
    }

    int64_t RemainingSilenceUs(int64_t now_us) const {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!active_ || speaking_) {
            return 0;
        }
        if (submitted_ || !heard_speech_) {
            return recognized_ ? 0 : std::max<int64_t>(1, no_input_deadline_us_ - now_us);
        }
        if (deadline_us_ == 0)
            return 0;
        return std::max<int64_t>(1, deadline_us_ - now_us);
    }

    bool SubmitIfDue(int64_t now_us) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!active_ || submitted_ || !heard_speech_ || speaking_ || deadline_us_ == 0 ||
            now_us < deadline_us_) {
            return false;
        }
        submitted_ = true;
        submitted_sequence_ = speech_sequence_;
        resume_from_us_ = 0;
        deadline_us_ = 0;
        no_input_deadline_us_ = now_us + kNoInputUs;
        return true;
    }

    bool SubmitManually(int64_t now_us) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!open_ || submitted_)
            return false;
        submitted_ = true;
        active_ = true;
        speaking_ = false;
        submitted_sequence_ = speech_sequence_;
        resume_from_us_ = 0;
        deadline_us_ = 0;
        no_input_deadline_us_ = now_us + kNoInputUs;
        return true;
    }

    bool ShouldReturnIdle(int64_t now_us) const {
        std::lock_guard<std::mutex> lock(mutex_);
        return active_ && !recognized_ && !speaking_ && (submitted_ || !heard_speech_) &&
               now_us >= no_input_deadline_us_;
    }

    bool RecognizeTranscript(const char* text, uint32_t generation) {
        if (text == nullptr)
            return false;
        bool has_text = false;
        for (const unsigned char* p = reinterpret_cast<const unsigned char*>(text); *p; ++p) {
            if (*p > ' ' && *p != 0x7f) {
                has_text = true;
                break;
            }
        }
        std::lock_guard<std::mutex> lock(mutex_);
        if (!has_text || !open_ || generation != generation_ || (require_vad_ && !heard_speech_)) {
            return false;
        }
        recognized_ = true;
        return true;
    }

    uint32_t Generation() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return generation_;
    }

    bool CanReply(uint32_t generation) const {
        std::lock_guard<std::mutex> lock(mutex_);
        return open_ && recognized_ && generation == generation_;
    }

    void FinishReply() {
        std::lock_guard<std::mutex> lock(mutex_);
        open_ = false;
        recognized_ = false;
        ++generation_;
    }

    bool HasSpeechAfterSubmit() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return submitted_ && speech_sequence_ != submitted_sequence_;
    }

    bool ResumeAfterSubmit() {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!submitted_ || speech_sequence_ == submitted_sequence_) {
            return false;
        }
        active_ = true;
        ++generation_;
        recognized_ = false;
        accept_audio_after_us_ = resume_from_us_;
        resume_from_us_ = 0;
        submitted_ = false;
        heard_speech_ = true;
        deadline_us_ = speaking_ ? 0 : last_silence_us_ + kSilenceUs;
        return true;
    }

    void Pause() {
        std::lock_guard<std::mutex> lock(mutex_);
        active_ = false;
        heard_speech_ = false;
        deadline_us_ = 0;
    }

    void Cancel() {
        std::lock_guard<std::mutex> lock(mutex_);
        active_ = false;
        open_ = false;
        recognized_ = false;
        ++generation_;
        submitted_ = false;
        heard_speech_ = false;
        speaking_ = false;
        resume_from_us_ = 0;
        deadline_us_ = 0;
    }

    bool AcceptsAudio(int64_t captured_at_us) const {
        std::lock_guard<std::mutex> lock(mutex_);
        return open_ && (!require_vad_ || heard_speech_) && !submitted_ &&
               captured_at_us >= accept_audio_after_us_;
    }

    bool IsActive() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return active_ && !submitted_;
    }

    bool IsSubmitted() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return submitted_;
    }

private:
    mutable std::mutex mutex_;
    bool active_ = false;
    bool speaking_ = false;
    bool heard_speech_ = false;
    bool submitted_ = false;
    bool open_ = false;
    bool recognized_ = false;
    bool require_vad_ = false;
    uint32_t generation_ = 0;
    uint32_t speech_sequence_ = 0;
    uint32_t submitted_sequence_ = 0;
    int64_t deadline_us_ = 0;
    int64_t last_silence_us_ = 0;
    int64_t last_speech_us_ = 0;
    int64_t accept_audio_after_us_ = 0;
    int64_t resume_from_us_ = 0;
    int64_t no_input_deadline_us_ = 0;
};
