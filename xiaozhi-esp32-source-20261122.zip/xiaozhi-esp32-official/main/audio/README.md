# Audio Service Architecture

`AudioService` owns one input engine and keeps codec I/O, Opus encoding/decoding,
and network queues independent from the chip-specific speech pipeline.

## Input engines

The old `AudioProcessor + WakeWord` combinations have been replaced by a single
`AudioEngine` interface. `AudioInputTask` reads PCM once and feeds exactly one
engine.

| Target | Engine | Wake word | Uplink processing |
| --- | --- | --- | --- |
| ESP32-S3 / ESP32-P4 / ESP32-S31 | `AfeAudioEngine` | WakeNet inside AFE, or MultiNet fed from AFE output | FD AEC + VAD when audio processing is enabled |
| ESP32 / ESP32-C3 / ESP32-C5 / ESP32-C6 | `LiteAudioEngine` | Standalone WakeNet when configured | Raw mono PCM |

`AfeAudioEngine` owns a single FD AFE instance. WakeNet and voice uplink share
that instance, so enabling both no longer creates two AFE pipelines. For custom
MultiNet wake words, AFE fetch output is passed to `CustomWakeWord`; MultiNet is
not created on the smaller targets.

The AFE configuration currently uses `FD_LOW_COST` AEC with
`AEC_NLP_LEVEL_VERYAGGR`. WebRTC/NSNet noise suppression is intentionally
disabled because the project does not ship an NSNet model.

When wake-word audio upload is enabled, the most recent two seconds of PCM are
stored in a single 64 KB PSRAM ring buffer. WakeNet and MultiNet share the same
cache implementation, and the encoder reads it one Opus frame at a time. This
avoids the previous per-chunk internal-SRAM allocations and temporary PCM
concatenation buffer.

## Input data flow

```mermaid
flowchart LR
    Mic[Microphone] --> Codec[AudioCodec]
    Codec --> Input[AudioInputTask]
    Input --> Engine[One AudioEngine]
    Engine --> Wake[Wake-word event]
    Engine --> PCM[16 kHz mono PCM]
    PCM --> EncodeQueue[audio_encode_queue_]
    EncodeQueue --> Opus[OpusCodecTask]
    Opus --> SendQueue[audio_send_queue_]
    SendQueue --> App[Application / network]
```

Wake-word detection and voice processing are independent runtime states on the
same engine. On AFE targets, AEC stays active while wake-word detection is active
so playback reference remains available for wake-up during device playback. It
also stays active during voice processing when device AEC is requested.

## Local input and reply boundaries

On engines with VAD, automatic/realtime listening uploads only after local VAD
has detected speech. One second of detected silence submits that input once.
A fresh turn with no speech returns to idle after three seconds; a submitted turn
with no nonempty STT result also closes after three seconds. Neither timeout
submits another empty turn. Manual PTT keeps capturing while held, then stops
capture and waits for its recognition/reply after release. Engines without VAD
retain server endpointing so a long spoken sentence is not cut off by a timer
that cannot distinguish speech from silence.

Recognition remains hidden on screen. A nonempty STT result authorizes only the
current turn's TTS start and captions. Empty/stale recognition and unsolicited
TTS cannot enter speaking. TTS stop consumes that authorization immediately,
before waiting for playback to drain and opening the next input; an old result
cannot authorize a self-conversation loop. The generation is checked again when
scheduled callbacks execute.

The fixed-size `VadTurn` state records both AFE VAD edges before the event bit can
merge them. It checks current deadlines, latches submission, and cancels timers
on state changes and disconnect. WebRTC VAD can initialize without a wake-word
model. Local capture times travel through encoding to reject old queued/in-flight
frames after a new `listen.start`; these times are never serialized or substituted
for server AEC timestamps.

The current Muse integration closes capture while speaking, waits for buffered
playback to drain, then applies its capture warmup before the next turn. Uplink
is allowed only while actually capturing in listening. These local rules do not
repair remote MQTT/TLS EOF; transport recovery remains separate.

## User mute

`AudioCodec` keeps user mute separate from the saved output volume. Muted frames
are zeroed and still written at their normal cadence. Box codecs also use DAC
hardware mute, including across output enable/disable, without closing/reopening
the shared I2S device. Volume controls, including MCP calls, do not clear user mute.
Muse's speaker setting is applied at its volume bridge entry point.

## Output data flow

```mermaid
flowchart LR
    App[Application / network] --> DecodeQueue[audio_decode_queue_]
    DecodeQueue --> Opus[OpusCodecTask]
    Opus --> PlaybackQueue[audio_playback_queue_]
    PlaybackQueue --> Output[AudioOutputTask]
    Output --> Codec[AudioCodec]
    Codec --> Speaker[Speaker]
```

## Tasks and power management

- `AudioInputTask` reads codec input and feeds the selected engine.
- `AudioOutputTask` drains decoded PCM to the codec output.
- `OpusCodecTask` encodes uplink PCM and decodes downlink packets.
- `AfeAudioEngine` has its own AFE fetch task on S3/P4/S31.

The audio power timer still enables and disables codec ADC/DAC channels based on
activity; the engine refactor does not change that policy.
