# Official firmware integration assessment

Checked on 2026-10-21. This is a source-feasibility assessment; no product source or device firmware was changed for this assessment.

## Goal

Keep the Waveshare multi-application desktop and actual Settings, MusicPlayer and supported media functions. Integrate the existing customized XiaoZhi experience inside AIChats: unchanged original portrait, nebula/animations, corrected status icons, conversation pagination, chat home, 180-second inactivity watch, and manual right-swipe watch.

The current workspace is based on 78/xiaozhi-esp32, not the complete Waveshare multi-app firmware. Its board-local demo launcher is not an implementation of the factory applications. Running this standalone application explains why the original desktop applications are not available.

## Verified official sources

1. ESP32-S3-Touch-AMOLED-1.75C main commit 4bfdc80eedbf95031e384610796bed15e0240312.
   - examples/esp-idf/03_esp-brookesia/README.md describes a Phone UI with one bundled SquareLine demo.
   - main/main.cpp installs applications from the Brookesia registry.
   - main/idf_component.yml selects LVGL 9.5.0 and waveshare/esp32_s3_touch_amoled_1_75c ^3.0.0.
   - sdkconfig.defaults disables the generic AI framework and services.
   - firmware/README.md supplies FactoryOnly_20260114.bin. No complete matching AIChats/MusicPlayer/Settings product project was identified in this main tree. This does not establish that such source is unavailable elsewhere.
2. The official sibling ESP32-S3-Touch-AMOLED-1.75 repository has firmware/brookesia/ source.
   - components/XiaozhiApp, MusicPlayer and Settings implement real applications.
   - Shared bsp_extra audio, storage_service and system_status coordinate audio ownership, files, battery and Wi-Fi.
   - Music supports MP3/WAV and a SPIFFS fallback; several other media functions depend on SD storage.
   - Its defaults use a 16MB layout, while this user's 1.75C has verified 32MB flash. It is a source reference, not a flash-compatible image.
   - Weather is not in this source project's documented application list. No promise is made that every icon in the reference product image already has an available backend.

## Recommended architecture

Use a complete multi-app Brookesia project with an explicitly identified 1.75C hardware port. Keep official desktop, app lifecycle, Settings, audio and storage ownership. Port the customized Aurora presentation into AIChats and bind its updates to that application's real voice/message callbacks. Do not transplant a second Application singleton, Wi-Fi manager, codec or display initialization.

The chat/watch policy belongs inside AIChats: chat is its default page; 180 seconds without actual touch/speech or a right swipe opens the watch. Exiting AIChats returns to the official desktop. These rules must not replace MusicPlayer or Settings screens. A global watch/screen-saver policy would require a separate explicit product decision.

Prefer the exact complete 1.75C factory application source if it can be obtained. Otherwise port the documented sibling product applications onto the 1.75C BSP, adapting pins through a unique board identity, partitions, absent peripherals, storage paths and codecs. Do not assume SD hardware exists on the C model or reuse sibling binaries.

## First implementation milestone

On a separate integration checkout, establish a reproducible 1.75C build with working real Settings and MusicPlayer before changing AIChats UI. Validate volume/brightness/Wi-Fi persistence, actual playback, native desktop return, and exclusive audio transfer between music and AIChats. Then port Aurora presentation and test original portrait, conversation text, three-minute inactivity and gestures. Measure SRAM/PSRAM use and application/filesystem partition capacity. Preserve the current customized source and recoverable device image throughout.

## Source links

- https://github.com/waveshareteam/ESP32-S3-Touch-AMOLED-1.75C/tree/4bfdc80eedbf95031e384610796bed15e0240312
- https://github.com/waveshareteam/ESP32-S3-Touch-AMOLED-1.75C/blob/4bfdc80eedbf95031e384610796bed15e0240312/examples/esp-idf/03_esp-brookesia/README.md
- https://github.com/waveshareteam/ESP32-S3-Touch-AMOLED-1.75C/blob/4bfdc80eedbf95031e384610796bed15e0240312/firmware/README.md
- https://github.com/waveshareteam/ESP32-S3-Touch-AMOLED-1.75/blob/main/firmware/brookesia/README.md
- https://github.com/waveshareteam/ESP32-S3-Touch-AMOLED-1.75/blob/main/firmware/brookesia/components/README.md
- https://github.com/waveshareteam/ESP32-S3-Touch-AMOLED-1.75/blob/main/docs/troubleshooting.md
