# Purple Portrait UI Implementation Plan

> **For agentic workers:** Execute the tasks in this session with verification after each task. Preserve all pre-existing worktree changes.

**Goal:** Implement the approved vivid purple nebula background, original-photo avatar and reply view without its title.

**Architecture:** Board-local native LVGL image descriptors read fixed-size RGB565 files. A small shared CMake helper generates the descriptors for both firmware and host rendering; all UI changes stay in the existing Aurora class.

**Tech Stack:** ESP-IDF, LVGL 9, C/C++, Python standard-library asset embedding, Pillow for offline format conversion only.

## Task 1: Assets and reversible checkpoint

- [x] Preserve current modified board sources, CMake and host tests beside the verified original device backup.
- [x] Save the approved mockup and generated clean nebula source in board-local assets; copy the original portrait unchanged.
- [x] Convert the background to 466×466 RGB565 and portrait to 160×160 RGB565 using a face-preserving crop of the original photo. Keep source images and conversion instructions for reproducibility.
- [x] Add `aurora_images.h`, a standard-library raw-to-C generator and `aurora_assets.cmake`; validate exact data lengths and reject malformed inputs. Share the helper between host tests and the selected board build.

## Task 2: UI implementation and rendered verification

- [x] Add a missing-feature assertion to the existing real-LVGL reply test: neither reply title is visible. Run it before the change and confirm the expected failure.
- [x] In `aurora_ui.cc/.h`, replace background widgets with a native-size image and the orb highlight with a clipped original-photo image and purple ring. Set reply title empty/hidden; enlarge reply avatar to 108px and idle avatar to 154px. Keep bounded safe geometry and existing state transitions.
- [x] Extend the host runner to save native rendered pixels. Render and inspect idle, listening and reply images, including a long multi-page reply. Run all LVGL tests and `python -m unittest discover -s scripts/tests -v`.
- [x] Update `AURORA_UI.md` with asset generation, layout and validation details. Format touched C/C++ only.

## Task 3: Build, review and device update

- [x] Run `python scripts/build.py waveshare/esp32-s3-touch-amoled-1.75 --name esp32-s3-touch-amoled-1.75c-aurora-32m` in the installed SDK environment. Verify partition equality and application size ≤ 0x3f0000.
- [x] Review changed image lifetime, clipping, state geometry, build guards and deployment addresses before writing hardware.
- [x] Save new immutable firmware copies/hashes and a separate deployment record. Use the same guarded device identity, partition and OTA checks as the previous deployment.
- [x] Write and independently verify ota_0; verify and preserve unchanged assets. Capture startup logs and report hardware-visible details requiring the user's observation.

## User additions during implementation

- [x] Remove all above-avatar state headings, including idle/listening/thinking, by deleting the title widget.
- [x] Replace the thinking subtitle with three staggered pulsing purple dots; verify animation cancellation on hide and on transition to reply.
- [x] Test and render against the actual common CBIN glyphs and 31px line metrics; use a 122px reply card limit to retain three lines.
