# WorkBuddy continuous-conversation review — 2026-10-28

## Findings and changes

The original silence handler relied on a coalesced event bit and the latest VAD boolean. It did not distinguish current-turn speech, stale timeouts, manual PTT, or an already submitted turn. After `listen.stop`, realtime capture also continued sending packets without a new `listen.start`.

- Record both AFE VAD edges with their actual callback times in a fixed-size, synchronized `VadTurn` state. Require speech, one full second of silence, and a current deadline before submitting once. Leave manual PTT unchanged.
- Cancel pending silence work on state changes and disconnect. Check the deadline again when an old timeout is consumed.
- Gate uplink packets after stop. Keep realtime VAD active for interruption, explicitly abort/restart before uploading the next utterance, and preserve short utterances when VAD events coalesce or TTS state handling runs first.
- Carry local capture times through PCM encoding and queued packets to reject old/in-flight audio after restart while retaining the first new speech frame. These times do not alter server AEC timestamps or WebSocket/MQTT serialization.
- Use atomic reads for `AudioService` voice state. No vendor/generated sources were manually edited.

## Evidence and validation

The production handlers first failed focused virtual-clock regression cases for stale timers, repeated submission and manual-mode behavior. Additional regressions reproduced old queued/late encoded packets leaking into the next turn, and short utterances being discarded when TTS finishes before VAD event handling. All now pass.

- 116 host tests passed, including 18 VAD lifecycle/send-loop regressions using production handlers and Protocol start/stop messages.
- Canonical board/variant build followed by the final incremental build passed with the documented Muse ESP-IDF 5.5.2 environment: `esp32-s3-touch-amoled-1.75c-aurora-32m`.
- Both transport implementations were checked: local capture times are not serialized. Changed C/C++ ranges pass repository formatting; `git diff --check` passes.
- Firmware was not flashed. Physical capture/playback, one-second pause feel, realtime interruption, AEC echo rejection, and actual server reconnect behavior remain hardware validation.

## Separate news-reply failure

`/tmp/muse-news-followup-20261028.log` records MQTT TLS EOF at 44.49 seconds and `speaking -> idle` at 44.57 seconds. That is a transport disconnect, not VAD silence waiting. The log also records successful WebRTC AFE VAD initialization without a wake-word model. This silence-boundary change does not fix the remote EOF; the separately implemented transport-recovery path still requires on-device verification.

This was a one-time review. The repeating `workbuddy` follow-up was deleted at the user's request.
