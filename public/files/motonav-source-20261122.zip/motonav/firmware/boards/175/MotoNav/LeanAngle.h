#pragma once
// QMI8658 adapter for the 1.75 inch board. Estimation math is host-testable in
// LeanAngleEstimator.h. #LEAN,Z requests an upright, stationary calibration.
#include <Arduino.h>
#include <Wire.h>
#include <Preferences.h>
#include "LeanAngleEstimator.h"

#ifndef LEAN_SIGN
#define LEAN_SIGN (-1.0f)
#endif

static LeanAngle::Estimator leanEstimator;
static LeanAngle::DisplayState leanDisplay;
static uint8_t leanAddr = 0;
static bool leanReady = false, leanOn = true, leanDebug = false;
static float leanMaxL = 0, leanMaxR = 0;
static uint32_t leanLastUs = 0, leanSpeedAt = 0;
static bool leanSpeedSeen = false;
static float leanSpeedMps = 0;
static LeanAngle::Vec leanAcc, leanGyro;
static bool leanSampleSeen = false, leanUnlockPending = false;
static uint32_t leanSampleCounter = 0;
static uint32_t leanProcessedUs = 0, leanMaxIntervalUs = 0;

static bool leanI2CRead(uint8_t reg, uint8_t *buf, uint8_t n) {
  if (!leanAddr) return false;
  Wire.beginTransmission(leanAddr); Wire.write(reg);
  if (Wire.endTransmission(false) != 0 || Wire.requestFrom(leanAddr, n) != n) return false;
  for (uint8_t i = 0; i < n; ++i) buf[i] = uint8_t(Wire.read());
  return true;
}
static bool leanI2CWrite(uint8_t reg, uint8_t value) {
  Wire.beginTransmission(leanAddr); Wire.write(reg); Wire.write(value);
  return Wire.endTransmission() == 0;
}
static bool leanWaitCommand(bool done) {
  const uint32_t start = millis();
  while (uint32_t(millis() - start) < 100) {
    uint8_t status = 0;
    if (!leanI2CRead(0x2D, &status, 1)) return false;
    if (bool(status & 0x80) == done) return true;
    delay(1);
  }
  return false;
}

static bool leanSaveSettings() {
  const LeanAngle::Settings s = leanEstimator.settings();
  Preferences pr;
  if (!pr.begin("motonav", false)) return false;
  // Keep the legacy mounting mean RAW, so older firmware can still read its
  // original physical zero. This firmware applies the separate accelBias on load.
  const auto rawZero = s.up * (1/s.accelScale) + s.accelBias;
  const auto rawUp = rawZero.unit();
  const float rawScale = 1/rawZero.norm();
  bool ok = pr.putBool("l3ok", false) != 0;
  ok = ok && pr.putFloat("l3ux", rawUp.x) && pr.putFloat("l3uy", rawUp.y) && pr.putFloat("l3uz", rawUp.z) &&
       pr.putFloat("l3bx", s.bias.x) && pr.putFloat("l3by", s.bias.y) && pr.putFloat("l3bz", s.bias.z) &&
       pr.putFloat("l3ax", s.accelBias.x) && pr.putFloat("l3ay", s.accelBias.y) && pr.putFloat("l3az", s.accelBias.z) &&
       pr.putFloat("l3as", rawScale) && pr.putFloat("leansgn", s.sign);
  if (ok) ok = pr.putBool("l3ok", s.calibrated) != 0;
  pr.end();
  return ok;
}

static bool leanBegin() {
  leanEstimator = LeanAngle::Estimator{};
  leanDisplay = LeanAngle::DisplayState{};
  leanReady = leanSpeedSeen = false; leanAddr = 0;
  leanSampleSeen = leanUnlockPending = false;
  leanProcessedUs = leanMaxIntervalUs = 0;
  leanMaxL = leanMaxR = 0;
  LeanAngle::Settings s;
  LeanAngle::Vec savedAccelBias;
  Preferences pr;
  if (pr.begin("motonav", true)) {
    leanOn = pr.getBool("leanon", true);
    s.sign = pr.getFloat("leansgn", LEAN_SIGN);
    s.calibrated = pr.getBool("l3ok", false);
    s.up = {pr.getFloat("l3ux", 0), pr.getFloat("l3uy", 1), pr.getFloat("l3uz", 0)};
    s.bias = {pr.getFloat("l3bx", 0), pr.getFloat("l3by", 0), pr.getFloat("l3bz", 0)};
    savedAccelBias = {pr.getFloat("l3ax", 0), pr.getFloat("l3ay", 0), pr.getFloat("l3az", 0)};
    s.accelScale = pr.getFloat("l3as", 1);
    pr.end();
  }
  leanEstimator.setSign(s.sign == 1 ? 1 : -1);
  if (s.calibrated) {
    bool restored = leanEstimator.restore(s);
    if (!savedAccelBias.finite() || savedAccelBias.norm() > .5f) restored = false;
    else if (restored && savedAccelBias.norm() > 0)
      restored = leanEstimator.setAccelerometerBias(savedAccelBias);
    if (!restored) {
      leanEstimator = LeanAngle::Estimator{};
      leanEstimator.setSign(s.sign == 1 ? 1 : -1);
      Serial.println("IMU: saved calibration invalid; #LEAN,Z required");
    }
  }
  leanEstimator.takeSettingsChanged();
  // Old z2ero is not migrated: it may have been learned on a sidestand.
  for (uint8_t addr : {uint8_t(0x6B), uint8_t(0x6A)}) {
    leanAddr = addr; uint8_t id = 0;
    if (leanI2CRead(0x00, &id, 1) && id == 0x05) break;
    leanAddr = 0;
  }
  if (!leanAddr || !leanI2CWrite(0x60, 0xB0)) {
    Serial.println("IMU: QMI8658 not found or reset failed"); return false;
  }
  delay(30);
  // +/-4g, +/-1024 dps, ODR 448.4Hz; both low-pass filters at ~12Hz.
  if (!leanI2CWrite(0x02, 0x40) || !leanI2CWrite(0x03, 0x14) ||
      !leanI2CWrite(0x04, 0x64) || !leanI2CWrite(0x06, 0x11) || !leanI2CWrite(0x09, 0x80) ||
      !leanI2CWrite(0x0B, 0x01) || !leanI2CWrite(0x0A, 0x12) || !leanWaitCommand(true) ||
      !leanI2CWrite(0x0A, 0x00) || !leanWaitCommand(false) || !leanI2CWrite(0x08, 0x83)) {
    Serial.println("IMU: configuration failed"); return false;
  }
  delay(80);
  uint8_t ctrl2 = 0, ctrl3 = 0, ctrl5 = 0, ctrl7 = 0;
  leanReady = leanI2CRead(0x03, &ctrl2, 1) && leanI2CRead(0x04, &ctrl3, 1) &&
              leanI2CRead(0x06, &ctrl5, 1) && leanI2CRead(0x08, &ctrl7, 1) &&
              ctrl2 == 0x14 && ctrl3 == 0x64 && ctrl5 == 0x11 && (ctrl7 & 0x83) == 0x83;
  leanLastUs = micros();
  Serial.printf("IMU: ready=%d calibrated=%d; keep motorcycle upright and send #LEAN,Z to calibrate\n",
                leanReady ? 1 : 0, leanEstimator.calibrated() ? 1 : 0);
  return leanReady;
}

static bool leanReadRaw() {
  // QST SyncSample protocol: STATUSINT starts locking; GZ_H releases it.
  // After an I2C error, discard any previously locked frame before accepting
  // new samples. Reading STATUS0 is NOT an unlock in this chip's protocol.
  uint8_t release = 0, status = 0;
  if (leanUnlockPending) {
    if (leanI2CRead(0x40, &release, 1)) leanUnlockPending = false;
    return false;
  }
  if (!leanI2CRead(0x2D, &status, 1)) { leanUnlockPending = true; return false; }
  if (!(status & 0x03)) return false;
  leanUnlockPending = true;
  if (!(status & 0x02)) {
    delayMicroseconds(12);                         // 448.4Hz lock delay, datasheet Table 40
    for (int i = 0; i < 4; ++i) {
      if (!leanI2CRead(0x2D, &status, 1) || (status & 0x02)) break;
    }
  }
  uint8_t b[17];                                   // timestamp, temperature, six axes through GZ_H
  if (!(status & 0x02) || !leanI2CRead(0x30, b, 17)) {
    if (leanI2CRead(0x40, &release, 1)) leanUnlockPending = false;
    return false;
  }
  leanUnlockPending = false;
  uint32_t counter = uint32_t(b[0]) | (uint32_t(b[1]) << 8) | (uint32_t(b[2]) << 16);
  if (leanSampleSeen && counter == leanSampleCounter) return false;
  leanSampleSeen = true; leanSampleCounter = counter;
  float v[6];
  for (int i = 0; i < 6; ++i) {
    int16_t raw = int16_t(uint16_t(b[5+2*i]) | (uint16_t(b[6+2*i]) << 8));
    v[i] = raw / (i < 3 ? 8192.f : 32.f);
  }
  leanAcc = {v[0], v[1], v[2]}; leanGyro = {v[3], v[4], v[5]};
  return true;
}
static void leanUpdateSpeed(int kmh, uint32_t nowMs) {
  leanSpeedSeen = kmh >= 0 && kmh <= 360;
  if (leanSpeedSeen) { leanSpeedMps = kmh / 3.6f; leanSpeedAt = nowMs; }
}
static void leanInvalidateSpeed() { leanSpeedSeen = false; }
static bool leanAngleAvailable() { return leanReady && leanEstimator.valid(micros()); }
static float leanValue() { return leanEstimator.angle(); }
static void leanResetMax() { leanMaxL = leanMaxR = 0; }
static void leanSetZero() {
  if (!leanReady) return;
  leanEstimator.requestZero();
  Serial.println("IMU: zero requested; hold motorcycle upright and stationary for at least 1.2s");
}
static bool leanSetAccelerometerBias(float x, float y, float z) {
  if (!leanReady || !leanEstimator.setAccelerometerBias({x,y,z})) return false;
  leanEstimator.takeSettingsChanged(); leanResetMax();
  bool saved = leanSaveSettings();
  Serial.println(saved ? "IMU: accelerometer bias saved; original mounting zero preserved" :
                         "IMU: accelerometer bias applied but settings save failed");
  return saved;
}
static void leanFlipSign() {
  leanEstimator.setSign(-leanEstimator.settings().sign); leanResetMax();
  leanEstimator.takeSettingsChanged();
  if (!leanSaveSettings()) Serial.println("IMU: direction changed but settings save failed");
}
static void leanSaveOn(bool on) {
  leanOn = on;
  Preferences pr;
  if (pr.begin("motonav", false)) { pr.putBool("leanon", on); pr.end(); }
}
static void leanTick(bool speedAllowed = true) {
  if (!leanReady) return;
  uint32_t nowUs = micros();
  if (uint32_t(nowUs - leanLastUs) < 8000) return;
  leanLastUs = nowUs;
  if (!leanReadRaw()) return;
  if (leanProcessedUs && uint32_t(nowUs-leanProcessedUs) > leanMaxIntervalUs)
    leanMaxIntervalUs = uint32_t(nowUs-leanProcessedUs);
  leanProcessedUs = nowUs;
  bool fresh = speedAllowed && leanSpeedSeen && uint32_t(millis() - leanSpeedAt) <= 2500;
  leanEstimator.update(leanAcc, leanGyro, nowUs, leanSpeedMps, fresh);
  if (leanEstimator.zeroStalled(nowUs)) {
    leanEstimator.cancelZero();
    Serial.println("IMU: zero calibration timed out; keep still for 1.2s and retry");
  }
  if (leanEstimator.takeSettingsChanged()) {
    bool saved = leanSaveSettings(); leanResetMax();
    Serial.println(saved ? "IMU: upright calibration saved" : "IMU: calibrated but settings save failed");
  }
  if (leanAngleAvailable()) {
    float v = leanValue();
    if (v > 2 && v > leanMaxR) leanMaxR = v;
    if (v < -2 && -v > leanMaxL) leanMaxL = -v;
  }
  if (leanDebug) {
    static uint32_t at = 0;
    if (uint32_t(millis() - at) >= 500) {
      at = millis(); const auto bias = leanEstimator.bias();
      Serial.printf("IMU a=(%.3f,%.3f,%.3f) g=(%.2f,%.2f,%.2f) roll=%.1f bias=(%.3f,%.3f,%.3f) valid=%d cal=%d pending=%d speedFresh=%d maxGapUs=%lu state=%d refAgeMs=%lu\n",
                    leanAcc.x, leanAcc.y, leanAcc.z, leanGyro.x, leanGyro.y, leanGyro.z,
                    leanValue(), bias.x, bias.y, bias.z, leanAngleAvailable() ? 1 : 0,
                    leanEstimator.calibrated() ? 1 : 0, leanEstimator.zeroPending() ? 1 : 0, fresh ? 1 : 0,
                    (unsigned long)leanMaxIntervalUs, int(leanEstimator.status(nowUs)),
                    (unsigned long)leanEstimator.referenceAgeMs(nowUs));
      leanMaxIntervalUs = 0;
    }
  }
}
