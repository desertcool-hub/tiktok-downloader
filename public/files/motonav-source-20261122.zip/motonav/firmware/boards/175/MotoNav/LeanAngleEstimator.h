#pragma once
#include <cmath>
#include <cstdint>

// Raw sensor axes; calibration accounts for the board's rotation on its mount.
// Forward is the horizontal projection of -Z (screen normal). Acceleration is in g,
// angular velocity in degrees/second; positive displayed angle means right lean.
namespace LeanAngle {
constexpr float Pi = 3.14159265359f;
constexpr float Radians = Pi / 180.f;
constexpr float Gravity = 9.80665f;
inline float clamp(float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }
struct Vec {
  float x = 0, y = 0, z = 0;
  Vec operator+(Vec b) const { return {x + b.x, y + b.y, z + b.z}; }
  Vec operator-(Vec b) const { return {x - b.x, y - b.y, z - b.z}; }
  Vec operator*(float k) const { return {x * k, y * k, z * k}; }
  float dot(Vec b) const { return x * b.x + y * b.y + z * b.z; }
  Vec cross(Vec b) const { return {y*b.z-z*b.y, z*b.x-x*b.z, x*b.y-y*b.x}; }
  float norm() const { return std::sqrt(dot(*this)); }
  bool finite() const { return std::isfinite(x) && std::isfinite(y) && std::isfinite(z); }
  Vec unit() const { float n = norm(); return n > .00001f ? *this * (1 / n) : Vec{}; }
};
struct Settings {
  Vec bias;
  Vec accelBias;
  Vec up = {0, 1, 0};
  float accelScale = 1;
  float sign = -1;
  bool calibrated = false;
};
enum class Status { Ready, Uncalibrated, Calibrating, BiasMissing, ReferenceMissing,
                    SensorFault, SampleStale, ReferenceExpired };

class Estimator {
 public:
  bool restore(const Settings &s) {
    if (!s.calibrated || !s.up.finite() || !s.bias.finite() || s.bias.norm() > 60 ||
        !s.accelBias.finite() || s.accelBias.norm() > .5f ||
        s.up.norm() < .9f || s.up.norm() > 1.1f || !std::isfinite(s.sign) ||
        std::fabs(s.sign) != 1 || !std::isfinite(s.accelScale) || s.accelScale < .8f ||
        s.accelScale > 1.25f || !setFrame(s.up.unit())) return false;
    settings_ = s; settings_.up = s.up.unit(); biasReady_ = true;
    initialized_ = healthy_ = false; haveTime_ = false; resetWindow();
    knownMoving_ = haveStaticReference_ = false;
    haveYawMean_ = false;
    zeroPending_ = false; zeroSinceUs_ = 0;
    return true;
  }
  void requestZero() { zeroPending_ = true; zeroSinceUs_ = 0; haveYawMean_ = false; resetWindow(); }
  // A pending request that never completes (movement, tilt held too long) must
  // not leave the display permanently unavailable.
  bool zeroStalled(uint32_t nowUs) const {
    return zeroPending_ && zeroSinceUs_ && uint32_t(nowUs - zeroSinceUs_) > 15000000;
  }
  void cancelZero() { zeroPending_ = false; zeroSinceUs_ = 0; resetWindow(); }
  void setSign(float sign) {
    if (sign == 1 || sign == -1) { settings_.sign = sign; changed_ = true; }
  }
  Settings settings() const { return settings_; }
  bool setAccelerometerBias(Vec bias) {
    if (!calibrated() || zeroPending_ || !bias.finite() || bias.norm() > .5f) return false;
    // Reconstruct the original raw calibration mean, then change its sensor
    // correction. Preserve the physical mounting zero, regardless of current pose.
    Vec rawZero = settings_.up * (1/settings_.accelScale) + settings_.accelBias;
    Vec correctedZero = rawZero-bias;
    float mag = correctedZero.norm();
    if (mag < .8f || mag > 1.25f || !setFrame(correctedZero.unit())) return false;
    settings_.accelBias = bias; settings_.up = correctedZero.unit(); settings_.accelScale = 1/mag;
    up_ = settings_.up;
    initialized_ = healthy_ = haveTime_ = haveStaticReference_ = haveYawMean_ = false;
    changed_ = true; resetWindow(); return true;
  }
  Vec bias() const { return settings_.bias; }
  // v7.20 live frame for the G meter: up_ tracks the earth vertical, forward_/
  // right_ are the vehicle axes fixed at calibration. Exposed read-only so the
  // G page can subtract gravity and split the residual into lat/lon.
  Vec up() const { return up_; }
  Vec forward() const { return forward_; }
  Vec right() const { return right_; }
  bool frameReady() const { return initialized_ && biasReady_; }
  bool biasReady() const { return biasReady_; }
  bool calibrated() const { return settings_.calibrated; }
  bool zeroPending() const { return zeroPending_; }
  bool still() const { return still_; }
  bool takeSettingsChanged() { bool c = changed_; changed_ = false; return c; }
  float angle() const {
    // Inclination of the calibrated lateral axis relative to horizontal. Unlike
    // Euler roll, it stays defined when fore/aft pitch reaches 90 degrees.
    float roll = std::asin(clamp(-up_.dot(right_), -1, 1)) / Radians;
    return clamp(-settings_.sign * roll, -90, 90);
  }
  Status status(uint32_t nowUs) const {
    if (!calibrated()) return Status::Uncalibrated;
    if (zeroPending_) return Status::Calibrating;
    if (!biasReady_) return Status::BiasMissing;
    if (!healthy_ && haveTime_) return Status::SensorFault;
    if (!initialized_) return Status::ReferenceMissing;
    if (uint32_t(nowUs-lastUs_) > 150000) return Status::SampleStale;
    if (uint32_t(nowUs-referenceUs_) > 10000000) return Status::ReferenceExpired;
    return Status::Ready;
  }
  bool valid(uint32_t nowUs) const { return status(nowUs) == Status::Ready; }
  uint32_t referenceAgeMs(uint32_t nowUs) const {
    return initialized_ ? uint32_t(nowUs-referenceUs_)/1000 : UINT32_MAX;
  }

  void update(Vec acc, Vec gyro, uint32_t nowUs, float speedMps, bool speedFresh) {
    if (!acc.finite() || !gyro.finite() || acc.norm() > 6 || gyro.norm() > 1500) {
      initialized_ = healthy_ = still_ = haveStaticReference_ = haveYawMean_ = false; resetWindow(); return;
    }
    if (zeroPending_ && !zeroSinceUs_) zeroSinceUs_ = nowUs;
    acc = acc - settings_.accelBias;
    speedFresh = speedFresh && std::isfinite(speedMps) && speedMps >= 0 && speedMps <= 100;
    const bool stopped = speedFresh && speedMps <= .3f;
    if (speedFresh) knownMoving_ = !stopped;
    float dt = haveTime_ ? uint32_t(nowUs - lastUs_) / 1000000.f : 0;
    const bool gap = haveTime_ && dt > .1f;
    if (gap) { initialized_ = haveStaticReference_ = haveYawMean_ = false; resetWindow(); }
    if (haveTime_ && dt <= 0) return;
    lastUs_ = nowUs; haveTime_ = healthy_ = true; still_ = false;

    // A speed of zero alone is insufficient: require a continuous stable window.
    // Unknown speed permits installation zero only after an explicit request.
    const bool calibrationAllowed = stopped || (zeroPending_ && !speedFresh);
    const bool offlineCandidate = biasReady_ && !speedFresh && !knownMoving_ && !zeroPending_;
    const float rawMag = acc.norm();
    Vec corrected = gyro - settings_.bias;
    // Clear only OLD static evidence on clear motion, without discarding the
    // averaging window. A newly qualified zero-mean window below may provide
    // fresh evidence even when its final individual gyro sample is a peak.
    if (offlineCandidate && corrected.norm() > 6.f) haveStaticReference_ = false;
    const bool quietGyro = zeroPending_ ? gyro.norm() < 60.f :
                           (biasReady_ ? corrected.norm() < (offlineCandidate ? 60.f : 1.5f) : gyro.norm() < 3.f);
    if ((calibrationAllowed || offlineCandidate) && quietGyro && rawMag > .80f && rawMag < 1.20f) {
      addWindow(acc, gyro, nowUs, !offlineCandidate);
      if (windowN_ >= 25 && uint32_t(nowUs - windowStartUs_) >= 1200000) {
        haveStaticReference_ = false;
        // Gravity correction may tolerate zero-mean angular tremor; calibration
        // and bias learning still require the stricter quiet-gyro window.
        if (windowStable(!offlineCandidate)) {
          const Vec meanA = sumA_ * (1.f / windowN_);
          const Vec meanG = sumG_ * (1.f / windowN_);
          still_ = windowStable();
          if (zeroPending_ && setFrame(meanA.unit())) {
            settings_.up = meanA.unit(); settings_.bias = meanG; settings_.calibrated = true;
            settings_.accelScale = 1 / meanA.norm();
            biasReady_ = initialized_ = true; up_ = settings_.up; referenceUs_ = nowUs;
            zeroPending_ = knownMoving_ = false; zeroSinceUs_ = 0; changed_ = true;
          } else if (stopped) {
            // Only externally confirmed zero speed permits learning gyro bias.
            settings_.bias = biasReady_ ? settings_.bias * .75f + meanG * .25f : meanG;
            biasReady_ = true;
          }
          // Static bench/parked display does not require GPS. Do not infer a
          // stop after losing a previously moving speed, or from a turning IMU.
          // Stable acceleration observes drift perpendicular to gravity. Only
          // rotation ABOUT apparent gravity must stay close to zero: that is
          // the unobservable yaw component that identifies a steady turn.
          const Vec residual = meanG-settings_.bias;
          if (!knownMoving_ && biasReady_ && residual.norm() < 2.f &&
              std::fabs(residual.dot(meanA.unit())) < .35f &&
              std::fabs(meanA.norm()*settings_.accelScale-1) < .12f) {
            staticReferenceUs_ = nowUs; haveStaticReference_ = true;
          }
        }
        resetWindow();
      }
    } else { resetWindow(); haveStaticReference_ = false; }
    if (!biasReady_) return;
    acc = acc * settings_.accelScale;
    const float aMag = acc.norm();
    corrected = gyro - settings_.bias;
    Vec omega = corrected * Radians;
    if (offlineCandidate && dt > 0 && !gap && aMag > .5f) {
      const float yaw = corrected.dot(acc.unit());
      const float gain = 1 - std::exp(-dt / .75f);
      yawMeanDps_ = haveYawMean_ ? yawMeanDps_ + gain * (yaw-yawMeanDps_) : yaw;
      haveYawMean_ = true;
    } else haveYawMean_ = false;

    if (initialized_ && dt > 0 && !gap) {
      // Rotate gravity in the sensor frame, using all three axes. This also
      // avoids accumulating yaw as roll when the screen is pitched on its mount.
      float rate = omega.norm();
      if (rate > .000001f) {
        Vec axis = omega * (1 / rate);
        float a = -rate * dt, c = std::cos(a), s = std::sin(a);
        up_ = (up_ * c + axis.cross(up_) * s + axis * (axis.dot(up_) * (1-c))).unit();
      }
    }

    // For forward velocity v*f, a_turn = omega cross (v*f). The IMU measures
    // this acceleration plus apparent up. Remove a_turn BEFORE gravity fusion.
    // A stationary offline window may use gravity directly. Known moving
    // speed that expires never silently turns into a stationary reference.
    bool staticReference = haveStaticReference_ && uint32_t(nowUs-staticReferenceUs_) <= 1500000;
    // During ordinary roll/pitch motion gravity remains observable without GPS.
    // Admit only a small correction that agrees with this frame's gyro prediction
    // and has no sustained rotation about apparent gravity. It cannot initialize
    // an unknown attitude or turn a previously moving vehicle into a parked one.
    const bool trackingReference = offlineCandidate && initialized_ && haveYawMean_ &&
        std::fabs(yawMeanDps_) < .35f && up_.dot(acc.unit()) > .998629535f;
    if ((speedFresh || staticReference || trackingReference) && !zeroPending_) {
      Vec reference = speedFresh ? acc - omega.cross(forward_) * (speedMps / Gravity) : acc;
      const float mag = reference.norm();
      // The real sensor's gravity magnitude changes with orientation. Use the
      // same scale tolerance after a qualified static window as with speed.
      if (mag > .88f && mag < 1.12f &&
          aMag > .5f && aMag < 2.8f) {
        reference = reference.unit();
        // Large disagreement is normally an impact, slip or wrong speed. A
        // stopped reference may recover after a gap; moving recovery is bounded.
        if (!initialized_ || stopped || staticReference || up_.dot(reference) > .8660254f) {
          if (!initialized_) { up_ = reference; initialized_ = true; }
          else {
            const float gain = 1 - std::exp(-dt * ((stopped || staticReference) ? 3.f : .8f));
            up_ = (up_ * (1-gain) + reference * gain).unit();
          }
          referenceUs_ = nowUs;
        }
      }
    }
  }

 private:
  bool setFrame(Vec up) {
    Vec f = Vec{0, 0, -1} + up * up.z;
    if (f.norm() < .35f) {
      // Gravity is nearly parallel to the screen normal (screen face up or face
      // down): heading is unobservable, so keep the stored forward and only
      // re-derive the lateral axis. Without this a flat calibration can never
      // succeed and the request would stay pending forever.
      Vec r = forward_.cross(up);
      if (r.norm() < .35f) r = Vec{0, 1, 0}.cross(up);
      if (r.norm() < .35f) r = Vec{1, 0, 0}.cross(up);
      if (r.norm() < .35f) return false;
      right_ = r.unit();
      forward_ = up.cross(right_).unit();
      return true;
    }
    forward_ = f.unit(); right_ = forward_.cross(up).unit(); return true;
  }
  void resetWindow() { windowN_ = 0; }
  void addWindow(Vec a, Vec g, uint32_t nowUs, bool restrictGyroChange) {
    // Reject clear movement immediately; judge small sensor noise / hand tremor
    // statistically over the whole window, rather than against one noisy sample.
    if (windowN_ && ((a - firstA_).norm() > .06f ||
        (restrictGyroChange && (g - firstG_).norm() > 6.f))) resetWindow();
    if (!windowN_) {
      firstA_ = tailA_ = a; firstG_ = g; sumA_ = sumG_ = earlyA_ = {};
      sumA2_ = sumG2_ = 0; earlyN_ = 0; windowStartUs_ = windowLastUs_ = nowUs;
    }
    if (uint32_t(nowUs - windowStartUs_) <= 250000) { earlyA_ = earlyA_ + a; ++earlyN_; }
    float gain = 1 - std::exp(-float(uint32_t(nowUs - windowLastUs_)) / 150000.f);
    tailA_ = tailA_ * (1-gain) + a * gain; windowLastUs_ = nowUs;
    sumA_ = sumA_ + a; sumG_ = sumG_ + g; ++windowN_;
    sumA2_ += a.dot(a); sumG2_ += g.dot(g);
  }
  bool windowStable(bool requireQuietGyro = true) const {
    Vec meanA = sumA_ * (1.f/windowN_), meanG = sumG_ * (1.f/windowN_);
    float aVariance = sumA2_/windowN_ - meanA.dot(meanA);
    float gVariance = sumG2_/windowN_ - meanG.dot(meanG);
    return aVariance < .0004f && (!requireQuietGyro || gVariance < 2.25f) && earlyN_ &&
           (tailA_ - earlyA_ * (1.f/earlyN_)).norm() < .02f;
  }
  Settings settings_;
  Vec up_ = {0, 1, 0}, forward_ = {0, 0, -1}, right_ = {1, 0, 0};
  bool biasReady_ = false, initialized_ = false, healthy_ = false, haveTime_ = false;
  bool zeroPending_ = false, changed_ = false, still_ = false;
  bool knownMoving_ = false, haveStaticReference_ = false;
  bool haveYawMean_ = false;
  float yawMeanDps_ = 0;
  uint32_t staticReferenceUs_ = 0;
  uint32_t lastUs_ = 0, referenceUs_ = 0, windowStartUs_ = 0, windowN_ = 0;
  uint32_t zeroSinceUs_ = 0;
  Vec firstA_, firstG_, sumA_, sumG_, earlyA_, tailA_;
  float sumA2_ = 0, sumG2_ = 0;
  uint32_t earlyN_ = 0, windowLastUs_ = 0;
};

class DisplayState {
 public:
  bool needsRedraw(uint32_t ms, bool available, float value) const {
    if (drawn_ && uint32_t(ms - drawnAt_) < 100) return false;
    return !drawn_ || available != available_ || (available && rounded(value) != value_);
  }
  void markDrawn(uint32_t ms, bool available, float value) {
    drawn_ = true; drawnAt_ = ms; available_ = available; value_ = available ? rounded(value) : 0;
  }
  static int rounded(float value) { return int(std::lround(clamp(value, -90, 90))); }
 private:
  bool drawn_ = false, available_ = false;
  uint32_t drawnAt_ = 0;
  int value_ = 0;
};
} // namespace LeanAngle
