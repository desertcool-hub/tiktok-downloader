// ================= v7.22 WiFi 自动联网 + 配网热点 =================
//
// 开机后按顺序试：NVS 里存的（配网页面写进去的）→ 下面硬编码的几组。
// 全都连不上，就把自己变成一个开放热点（默认 192.168.4.1），DNS 劫持 + 网页配网，
// 手机连上会自动弹「登录到网络」的页面，选个 2.4G 网络、填密码就行。
//
// 硬编码那几组不是编的：这块板子（MAC b8:1f:3f:ca:eb:68）2026-10-20 跑小智时的整片备份里，
// nvs 分区的 wifi 命名空间存的就是 testonelife_inc_2.4 / Life1234，旁边还有一组 junfu / 1234567890。
// 换地方了改 kFallback[] 即可；配网页面写进去的会存 NVS，优先级比这里高，
// 也支持串口/BLE 直接打 "#WIFI,S,SSID,密码" 立刻换（存 NVS，不用重烧）。

#ifndef MOTONAV_WIFI_LINK_H
#define MOTONAV_WIFI_LINK_H

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Preferences.h>
#include <time.h>

namespace WifiLink {

// ---------------- 可改的几处 ----------------
struct Cred { const char *ssid; const char *pass; };
static const Cred kFallback[] = {
    {"mumu",                "bandit7758"},   // v7.22.2 用户新加的那台
    {"testonelife_inc_2.4", "Life1234"},     // 小智备份里那条
    {"junfu",               "1234567890"},   // 备份里另一条（手机热点？）
};
static const int kFallbackN = (int)(sizeof(kFallback) / sizeof(kFallback[0]));

// 热点名后缀取自 MAC 后 2 字节，形如 MotoNav-CAEB；开放网络，不设密码。
static const char *kApPrefix = "MotoNav-";
static const IPAddress kApIp(192, 168, 4, 1);
static const IPAddress kApMask(255, 255, 255, 0);

// 时间同步：连上网就顺手校一次，省得待机时钟非要等手机报 #CLK
static const char *kTz        = "CST-8";     // 东八区
static const char *kNtp1      = "ntp.aliyun.com";
static const char *kNtp2      = "ntp.tencent.com";
static const char *kNtp3      = "pool.ntp.org";

// 时序
static const uint32_t CONNECT_TIMEOUT_MS = 9000;    // 单个热点试多久
static const uint32_t AP_TRY_TIMEOUT_MS  = 18000;   // 配网页里连一个网试多久
static const uint32_t AP_IDLE_MS         = 600000;  // 10 分钟没人来配网就收摊
static const uint32_t AP_CLOSE_DELAY_MS  = 4000;    // 连上了留 4 秒，让页面看到"已连上"

enum : uint8_t { ST_OFF = 0, ST_CONNECTING, ST_STA, ST_AP, ST_AP_TRY };

// ---------------- 状态 ----------------
static bool     on         = false;
static uint8_t  st         = ST_OFF;
static uint32_t stAt       = 0;
static uint32_t apAt       = 0;
static uint32_t apCloseAt  = 0;
static uint32_t ntpAt      = 0;
static bool     tryOk      = false;
static int      lastErr    = 0;      // 0 无 / 1 找不到网络 / 2 密码错 / 3 超时 / 4 其它

static const int kMaxCand = 6;                  // NVS 那条 + kFallback 全部塞得下
static String   candSsid[kMaxCand], candPass[kMaxCand];
static int      candN = 0, candI = 0;

static String   apName;
static String   triedSsid;
static String   okSsid, okIp;
static String   apTrySsid;

static const int kMaxScan = 16;
static String   scanList[kMaxScan];
static int      scanRssi[kMaxScan];
static int      scanN = 0;

static bool     timeFresh = false;
static int      pubMin = -1;         // 上次发布的分钟数，变了才再发一次
static int      tH = 0, tM = 0, tMo = 0, tD = 0, tY = 0;

static DNSServer dns;
static WebServer server(80);
static bool      portalUp = false;
static String    portalHtmlCache;

// ---------------- 小工具 ----------------
static inline String errText(int e) {
  switch (e) {
    case 1: return "找不到这个网络";
    case 2: return "密码不对";
    case 3: return "连接超时";
    case 4: return "连接被拒绝";
    default: return "";
  }
}

static inline void noteStatus() {
  switch (WiFi.status()) {
    case WL_NO_SSID_AVAIL: lastErr = 1; break;
    case WL_CONNECT_FAILED: lastErr = 2; break;
    case WL_CONNECTED: lastErr = 0; break;
    default: lastErr = 3; break;
  }
}

static void buildCandidates() {
  candN = 0;
  Preferences pr;
  if (pr.begin("motonav", true)) {
    String s = pr.getString("wssid", "");
    String p = pr.getString("wpass", "");
    pr.end();
    if (s.length() && candN < kMaxCand) { candSsid[candN] = s; candPass[candN] = p; candN++; }
  }
  for (int k = 0; k < kFallbackN && candN < kMaxCand; k++) {
    bool dup = false;
    for (int i = 0; i < candN; i++)
      if (candSsid[i] == kFallback[k].ssid) dup = true;
    if (dup) continue;
    candSsid[candN] = kFallback[k].ssid;
    candPass[candN] = kFallback[k].pass;
    candN++;
  }
}

static void makeApName() {
  uint8_t mac[6] = {0};
  WiFi.macAddress(mac);
  char b[20];
  snprintf(b, sizeof(b), "%s%02X%02X", kApPrefix, mac[4], mac[5]);
  apName = b;
}

// ---------------- 网页 ----------------
static const char kPortalHtml[] PROGMEM = R"HTML(<!doctype html><html><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MotoNav WiFi</title><style>
:root{color-scheme:dark}
body{margin:0;padding:24px 18px 40px;font:16px/1.5 -apple-system,system-ui,sans-serif;background:#07090c;color:#e8eef5}
h1{margin:0 0 2px;font-size:21px;color:#39e1f0;letter-spacing:.5px}
p.sub{margin:0 0 20px;font-size:13px;color:#8c9aa8}
label{display:block;margin:16px 0 6px;font-size:12px;color:#8c9aa8;letter-spacing:.5px}
select,input{width:100%;box-sizing:border-box;padding:13px;border-radius:11px;border:1px solid #24303c;background:#101720;color:#e8eef5;font-size:16px}
button{width:100%;margin-top:16px;padding:14px;border:0;border-radius:11px;background:#39e1f0;color:#04141a;font-size:16px;font-weight:600}
button.ghost{margin-top:8px;background:#16202b;color:#9fb3c6;font-weight:400}
#st{margin-top:16px;font-size:13px;min-height:22px;color:#8c9aa8;word-break:break-all}
.ok{color:#5ef08a}.bad{color:#ff6b6b}
</style></head><body>
<h1>MotoNav</h1><p class="sub">给圆屏选一个 2.4G 网络</p>
<label>附近的网络</label>
<select id="list"><option value="">-- 正在扫描 --</option></select>
<button class="ghost" onclick="scan()">重新扫描</button>
<label>SSID</label>
<input id="ssid" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="也可以直接手打">
<label>密码</label>
<input id="pass" type="password" placeholder="开放网络留空">
<button onclick="go()">连接</button>
<div id="st"></div>
<script>
function el(i){return document.getElementById(i)}
function scan(){var s=el('list');s.innerHTML='<option value="">正在扫描…</option>';
 fetch('/scan').then(function(r){return r.json()}).then(function(a){
  s.innerHTML='<option value="">-- 选一个 --</option>';
  for(var i=0;i<a.length;i++){var o=document.createElement('option');o.value=a[i];o.textContent=a[i];s.appendChild(o)}
  if(!a.length){s.innerHTML='<option value="">没扫到，手打吧</option>'}
 }).catch(function(){s.innerHTML='<option value="">扫描失败，手打吧</option>'})}
el('list').onchange=function(){if(this.value)el('ssid').value=this.value}
function go(){var s=el('ssid').value.trim();if(!s){setS('先填 SSID','bad');return}
 setS('正在连接 '+s+' …','');
 fetch('/save',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
  body:'ssid='+encodeURIComponent(s)+'&pass='+encodeURIComponent(el('pass').value)})
 .then(function(){poll()})}
function setS(t,c){var e=el('st');e.textContent=t;e.className=c||''}
function poll(){fetch('/status').then(function(r){return r.json()}).then(function(j){
 if(j.st==='ok'){setS('已连上 '+j.ssid+'，热点马上关闭','ok');return}
 if(j.st==='fail'){setS('失败：'+j.msg,'bad');return}
 setS('正在连接 '+(j.ssid||'')+' …','');setTimeout(poll,1200)})}
window.onload=function(){scan()}
</script></body></html>)HTML";

static void handleScan() {
  String j = "[";
  for (int i = 0; i < scanN; i++) {
    if (i) j += ",";
    String s = scanList[i];
    s.replace("\\", "\\\\"); s.replace("\"", "\\\"");
    j += "\"" + s + "\"";
  }
  j += "]";
  server.send(200, "application/json", j);
}

static void handleRoot() {
  if (!portalHtmlCache.length()) portalHtmlCache = String(kPortalHtml);
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "text/html; charset=utf-8", portalHtmlCache);
}

static void handleStatus() {
  String name, s;
  if (st == ST_AP_TRY) { s = tryOk ? "ok" : "try"; name = apTrySsid; }
  else if (st == ST_STA) { s = "ok"; name = okSsid; }
  else { s = (st == ST_AP && lastErr) ? "fail" : "ap"; name = ""; }
  String j = "{\"st\":\"" + s + "\",\"ssid\":\"" + name + "\",\"msg\":\"" + errText(lastErr) + "\"}";
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", j);
}

static void handleSave() {
  String s = server.arg("ssid"); s.trim();
  String p = server.arg("pass");
  if (!s.length()) { server.send(400, "application/json", "{\"ok\":0}"); return; }
  if (p.length() > 63) p = p.substring(0, 63);
  Preferences pr;
  if (pr.begin("motonav", false)) { pr.putString("wssid", s); pr.putString("wpass", p); pr.end(); }
  Serial.printf("WIFI: portal save '%s'\n", s.c_str());
  WiFi.mode(WIFI_AP_STA);                       // 热点留着，页面还能回话
  WiFi.begin(s.c_str(), p.c_str());
  apTrySsid = s; lastErr = 0; tryOk = false;
  st = ST_AP_TRY; stAt = millis();
  server.send(200, "application/json", "{\"ok\":1}");
}

// 连不上任何东西时把热点支起来（DNS 劫持所有域名 → 配网页）
static void startAP() {
  if (!apName.length()) makeApName();
  buildCandidates();
  WiFi.persistent(false);
  WiFi.mode(WIFI_AP_STA);
  WiFi.disconnect(false, false);

  // 先扫一遍再开热点：扫描时断一下客户端无所谓，现在一个都没连
  scanN = 0;
  int n = WiFi.scanNetworks(false, false);
  for (int i = 0; i < n && scanN < kMaxScan; i++) {
    String s = WiFi.SSID(i);
    if (!s.length()) continue;
    bool dup = false;
    for (int k = 0; k < scanN; k++) if (scanList[k] == s) dup = true;
    if (dup) continue;
    scanList[scanN] = s;
    scanRssi[scanN] = WiFi.RSSI(i);
    scanN++;
  }
  for (int a = 1; a < scanN; a++) {             // 信号强的排前面
    String s = scanList[a]; int r = scanRssi[a]; int b = a - 1;
    while (b >= 0 && scanRssi[b] < r) { scanList[b + 1] = scanList[b]; scanRssi[b + 1] = scanRssi[b]; b--; }
    scanList[b + 1] = s; scanRssi[b + 1] = r;
  }
  WiFi.scanDelete();

  WiFi.softAPConfig(kApIp, kApIp, kApMask);
  WiFi.softAP(apName.c_str(), nullptr, 1, 0, 4);
  delay(120);
  dns.setErrorReplyCode(DNSReplyCode::NoError);
  dns.start(53, "*", kApIp);

  if (!portalUp) {
    server.on("/", handleRoot);
    server.on("/scan", handleScan);
    server.on("/status", handleStatus);
    server.on("/save", HTTP_POST, handleSave);
    server.onNotFound(handleRoot);
    server.begin();
    portalUp = true;
  }
  st = ST_AP; apAt = millis(); lastErr = 0; tryOk = false;
  Serial.printf("WIFI: AP '%s' up at %s, %d nets scanned\n", apName.c_str(),
                WiFi.softAPIP().toString().c_str(), scanN);
}

static void stopAP() {
  if (!portalUp && st != ST_AP && st != ST_AP_TRY) return;
  dns.stop();
  server.stop();
  portalUp = false;
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_STA);
  Serial.println("WIFI: AP down");
}

static void onStaOk() {
  okSsid = WiFi.SSID();
  okIp = WiFi.localIP().toString();
  lastErr = 0;
  st = ST_STA; stAt = millis();
  Serial.printf("WIFI: connected '%s' ip=%s rssi=%d\n", okSsid.c_str(), okIp.c_str(), (int)WiFi.RSSI());
  configTzTime(kTz, kNtp1, kNtp2, kNtp3);
  ntpAt = millis() + 2500;
}

static void tryNext() {
  if (candI >= candN) { startAP(); return; }
  triedSsid = candSsid[candI];
  WiFi.persistent(false);
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(false);
  WiFi.begin(candSsid[candI].c_str(), candPass[candI].c_str());
  st = ST_CONNECTING; stAt = millis();
  Serial.printf("WIFI: try '%s' (%d/%d)\n", triedSsid.c_str(), candI + 1, candN);
}

static void beginAttempts() {
  buildCandidates();
  candI = 0;
  lastErr = 0;
  if (!apName.length()) makeApName();
  if (!candN) { startAP(); return; }
  tryNext();
}

// ---------------- 对外 ----------------
static inline bool   enabled()   { return on; }
static inline bool   apActive()  { return st == ST_AP || st == ST_AP_TRY; }
static inline bool   staOk()     { return st == ST_STA && WiFi.status() == WL_CONNECTED; }
static inline bool   trying()    { return st == ST_AP_TRY; }
static inline bool   portal()    { return portalUp; }
static inline int    state()     { return st; }
static inline String apSsid()    { return apName; }
static inline String staSsid()   { return okSsid; }
static inline String staIp()     { return okIp; }
static inline int    error()     { return lastErr; }
static inline String apIpText()  { return kApIp.toString(); }

static String stateText() {
  switch (st) {
    case ST_CONNECTING: return String("connecting ") + triedSsid;
    case ST_STA:        return String("connected ") + okSsid + " " + okIp;
    case ST_AP:         return String("ap ") + apName;
    case ST_AP_TRY:     return String("ap-try ") + apTrySsid;
    default:            return "off";
  }
}

static void setEnabled(bool v) {
  Preferences pr;
  if (pr.begin("motonav", false)) { pr.putBool("wifien", v); pr.end(); }
  if (v == on) return;
  on = v;
  if (!v) {
    stopAP();
    WiFi.disconnect(true, false);
    WiFi.mode(WIFI_OFF);
    st = ST_OFF;
    Serial.println("WIFI: off");
  } else {
    beginAttempts();
  }
}

static void forget() {
  Preferences pr;
  if (pr.begin("motonav", false)) {
    pr.remove("wssid");
    pr.remove("wpass");
    pr.end();
  }
  Serial.println("WIFI: credentials cleared");
  stopAP();
  WiFi.disconnect(true, false);
  beginAttempts();
}

// 串口/BLE 直接换一组凭据：存 NVS（优先级高于 kFallback）后马上试，不用重烧固件
static void setCredential(const String &ssid, const String &pass) {
  String s = ssid; s.trim();
  String p = pass;
  if (!s.length()) { Serial.println("WIFI: empty ssid, ignored"); return; }
  if (p.length() > 63) p = p.substring(0, 63);
  Preferences pr;
  if (pr.begin("motonav", false)) { pr.putString("wssid", s); pr.putString("wpass", p); pr.end(); }
  Serial.printf("WIFI: creds saved '%s' (pass %d chars)\n", s.c_str(), (int)p.length());
  if (!on) { on = true; }
  stopAP();
  WiFi.disconnect(false, false);
  beginAttempts();
}

static void startAPNow() {
  stopAP();
  WiFi.disconnect(false, false);
  startAP();
}

// 有新的一分钟时间就交给调用方（一天最多 1440 次，够用）
static bool takeTime(int &hh, int &mm, int &mo, int &dd, int &yy) {
  if (!timeFresh) return false;
  timeFresh = false;
  hh = tH; mm = tM; mo = tMo; dd = tD; yy = tY;
  return true;
}

static void begin() {
  Preferences pr;
  bool want = true;
  if (pr.begin("motonav", true)) { want = pr.getBool("wifien", true); pr.end(); }
  on = want;
  if (!on) { Serial.println("WIFI: disabled in NVS"); return; }
  beginAttempts();
}

// 每 loop 调一次，全程非阻塞（扫描那 2 秒除外，只发生在开热点时）
static void tick() {
  if (!on) return;
  uint32_t now = millis();
  switch (st) {
    case ST_CONNECTING:
      if (WiFi.status() == WL_CONNECTED) { onStaOk(); }
      else if (now - stAt > CONNECT_TIMEOUT_MS) {
        noteStatus();
        Serial.printf("WIFI: '%s' failed (%d)\n", triedSsid.c_str(), lastErr);
        candI++;
        tryNext();
      }
      break;

    case ST_STA:
      if (WiFi.status() != WL_CONNECTED) {
        if (now - stAt > 4000) { WiFi.reconnect(); stAt = now; Serial.println("WIFI: link lost, reconnect"); }
      } else if ((int32_t)(now - ntpAt) >= 0) {
        ntpAt = now + 5000;
        time_t t = time(nullptr);
        if (t > 1700000000) {
          struct tm tmv;
          localtime_r(&t, &tmv);
          int cur = tmv.tm_hour * 60 + tmv.tm_min;
          // 只有跨分钟才发布一次，避免调用方每秒都去重画
          if (cur != pubMin || tmv.tm_mon + 1 != tMo || tmv.tm_mday != tD) {
            pubMin = cur;
            tH = tmv.tm_hour; tM = tmv.tm_min;
            tMo = tmv.tm_mon + 1; tD = tmv.tm_mday; tY = tmv.tm_year + 1900;
            timeFresh = true;
          }
        }
      }
      break;

    case ST_AP:
    case ST_AP_TRY:
      if (portalUp) { dns.processNextRequest(); server.handleClient(); }
      if (st == ST_AP_TRY) {
        if (WiFi.status() == WL_CONNECTED) {
          if (!tryOk) {
            tryOk = true; apCloseAt = now + AP_CLOSE_DELAY_MS;
            okSsid = apTrySsid; okIp = WiFi.localIP().toString(); lastErr = 0;
            configTzTime(kTz, kNtp1, kNtp2, kNtp3);
            ntpAt = now + 2500;
            Serial.printf("WIFI: portal ok '%s' ip=%s\n", okSsid.c_str(), okIp.c_str());
          } else if ((int32_t)(now - apCloseAt) >= 0) {
            stopAP();
            st = ST_STA; stAt = now;
            buildCandidates();
          }
        } else if (now - stAt > AP_TRY_TIMEOUT_MS) {
          noteStatus();
          Serial.printf("WIFI: portal try failed (%d)\n", lastErr);
          WiFi.disconnect(false, false);
          st = ST_AP; apAt = now; tryOk = false;
        }
      } else if (now - apAt > AP_IDLE_MS) {
        Serial.println("WIFI: nobody configured the AP in 10 min, giving up");
        stopAP();
        st = ST_OFF;
      }
      break;

    default: break;
  }
}

}  // namespace WifiLink

#endif
